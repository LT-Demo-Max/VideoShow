
Model catalog hierarchy:

-model
--vgg.pth
--val
---model.pth